
package SelectionSort;


public class main {

    public static void main(String[] args) {
        
        
        SelectionSort sort=new SelectionSort();
        
        int [] numeros = {3,4,5,1,2,7};
        sort.ordenar(numeros);
        sort.imprimir(numeros);
        
        
        
        
    }
    
}
