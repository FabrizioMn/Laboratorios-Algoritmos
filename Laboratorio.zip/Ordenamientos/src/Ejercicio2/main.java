
package Ejercicio2;


public class main {


    public static void main(String[] args) {
        String[]animales = {"perro","gato","elefante","raton","leon","tigre"};
        ordenBurbuja sort = new ordenBurbuja();
        sort.orden(animales);
        sort.imprimir(animales);
        
        
        
    }
    
}
