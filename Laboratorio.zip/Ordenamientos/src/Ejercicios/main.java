
package Ejercicios;


public class main {


    public static void main(String[] args) {
       ordenamiento sort=new ordenamiento();
        
        int [] numeros = {64,34,25,12,22,11,90};
        sort.ordenarDescendente(numeros);
        sort.imprimir(numeros);
        
        
        
    }
    
}
