
package Ejercicio3;


public class main {

    public static void main(String[] args) {
        
        ordenBurbujaDoble orden = new ordenBurbujaDoble();
        
        int a[]={23, 45, 12, 6, 78, 90, 34,56, 89, 9};
        
        orden.ordenamiento(a,"desc");
        
    }
    
}
